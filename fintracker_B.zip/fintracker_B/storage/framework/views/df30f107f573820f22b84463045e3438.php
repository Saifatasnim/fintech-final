

<?php $__env->startSection('content'); ?>

<div class="page-body">
    <!-- Basic table card start -->
    <div class="card">
        <div class="card-header">
            <h5>Member List</h5><br>
            <a href="<?php echo e(route('members.create')); ?>" class="btn btn-primary">
                Add Member
            </a>
            <div class="card-header-right">
                <ul class="list-unstyled card-option">
                    <li><i class="icofont icofont-simple-left "></i></li>
                    <li><i class="icofont icofont-maximize full-card"></i></li>
                    <li><i class="icofont icofont-minus minimize-card"></i></li>
                    <li><i class="icofont icofont-refresh reload-card"></i></li>
                    <li><i class="icofont icofont-error close-card"></i></li>
                </ul>
            </div>
        </div>
        <div class="card-block table-border-style">
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Name</th>
                            <th>Phone</th>
                            <th>Email</th>
                            <th>NID</th>
                            <th>Address</th>
                            <th>Nominee Name</th>
                            <th>Nominee Relation</th>
                            <th>Member ID</th>
                            <th>Assign Date</th>
                            <th>Photo</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <th scope="row"><?php echo e($loop->iteration); ?></th>
                                <td><?php echo e($member->name); ?></td>
                                <td><?php echo e($member->phone); ?></td>
                                <td><?php echo e($member->email); ?></td>
                                <td><?php echo e($member->nid); ?></td>
                                <td><?php echo e($member->address); ?></td>
                                <td><?php echo e($member->nominee_name); ?></td>
                                <td><?php echo e($member->nominee_relation); ?></td>
                                <td><?php echo e($member->member_id); ?></td>
                                <td><?php echo e($member->member_assign_date); ?></td>
                                <td>
                                    <?php if($member->photo): ?>
                                        <img src="<?php echo e(asset('storage/' . $member->photo)); ?>" alt="Photo" width="50">
                                    <?php else: ?>
                                        No Photo
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('members.edit', $member->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                                    <form action="<?php echo e(route('members.destroy', $member->id)); ?>" method="POST" style="display:inline;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="12" class="text-center">No members found</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Brac Project\example-app\resources\views/members/index.blade.php ENDPATH**/ ?>