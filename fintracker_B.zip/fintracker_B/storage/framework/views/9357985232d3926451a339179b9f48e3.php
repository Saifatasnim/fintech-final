


<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card">
        <div class="card-header">Total Deposits</div>
        <div class="card-body">
            <h5 class="card-title">$<?php echo e(number_format($totalDeposits, 2)); ?></h5>
        </div>
    </div>

    <table class="table">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Amount</th>
                <th scope="col">Fine</th>
                <th scope="col">Date</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $deposits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deposit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($loop->index + 1); ?></th>
                    <td>$<?php echo e(number_format($deposit->amount, 2)); ?></td>
                    <td>$<?php echo e(number_format($deposit->fine, 2)); ?></td>
                    <td><?php echo e($deposit->created_at->format('Y-m-d')); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Brac Project\fintracker\fintracker_B\resources\views/mydeposit/showDeposit.blade.php ENDPATH**/ ?>