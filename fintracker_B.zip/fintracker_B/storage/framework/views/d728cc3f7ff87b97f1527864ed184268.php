<!DOCTYPE html>
<html>
<head>
    <title>Deposit Slip</title>
</head>
<body>
    <h1>Deposit Slip</h1>
    <p>Hello <?php echo e($member->name); ?>,</p>
    <p>This is your deposit slip for the amount of $<?php echo e(number_format($deposit->amount, 2)); ?>.</p>
    <p>Thank you for your deposit on <?php echo e($deposit->created_at->toFormattedDateString()); ?>.</p>
</body>
</html>
<?php /**PATH D:\Brac Project\fintracker\fintracker_B\resources\views/deposit/email_slip.blade.php ENDPATH**/ ?>