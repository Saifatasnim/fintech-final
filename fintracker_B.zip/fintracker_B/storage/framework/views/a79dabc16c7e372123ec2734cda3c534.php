

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Submit Application</h2>
    <form action="<?php echo e(route('member-applications.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="email">Email</label>
            <input type="email" class="form-control" name="email" required>
        </div>
        <div class="form-group">
            <label for="subject">Subject</label>
            <input type="text" class="form-control" name="subject" required>
        </div>
        <div class="form-group">
            <label for="body">Application Body</label>
            <textarea class="form-control" name="body" rows="5" required></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Brac Project\fintracker\fintracker_B\resources\views/member_applications/create.blade.php ENDPATH**/ ?>