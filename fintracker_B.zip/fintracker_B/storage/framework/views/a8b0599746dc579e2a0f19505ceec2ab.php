

<?php $__env->startSection('content'); ?>
<div class="page-body">
    <div class="row">
        <div class="col-sm-12">
            <div class="card">
                <div class="card-header">
                    <h5>Edit Expense</h5>
                </div>
                <div class="card-block">
                    <form action="<?php echo e(route('expenses.update', $expense->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label">Amount</label>
                            <div class="col-sm-10">
                                <input type="number" name="amount" class="form-control" value="<?php echo e($expense->amount); ?>" required>
                            </div>
                        </div>

                        <div class="form-group row">
    <label class="col-sm-2 col-form-label">Category</label>
    <div class="col-sm-10">
        <select name="category" class="form-control" required>
            <option value="Transport" <?php echo e($expense->category == 'Transport' ? 'selected' : ''); ?>>Transport</option>
            <option value="Office Cost" <?php echo e($expense->category == 'Office Cost' ? 'selected' : ''); ?>>Office Cost</option>
            <option value="Food" <?php echo e($expense->category == 'Food' ? 'selected' : ''); ?>>Food</option>
            <option value="Meeting Cost" <?php echo e($expense->category == 'Meeting Cost' ? 'selected' : ''); ?>>Meeting Cost</option>
        </select>
    </div>
</div>


                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label">Date</label>
                            <div class="col-sm-10">
                                <input type="date" name="date" class="form-control" value="<?php echo e($expense->date); ?>" required>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label">Description</label>
                            <div class="col-sm-10">
                                <textarea name="description" class="form-control" rows="3" required><?php echo e($expense->description); ?></textarea>
                            </div>
                        </div>

                        <button type="submit" class="btn btn-primary">Update Expense</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Brac Project\fintracker\fintracker_B\resources\views/expenses/edit.blade.php ENDPATH**/ ?>