

<?php $__env->startSection('content'); ?>

<div class="page-body">
    <div class="row">
        <div class="col-sm-12">
            <div class="card">
                <div class="card-header">
                    <h5>Deposit List</h5>
                    <a href="<?php echo e(route('deposits.create')); ?>" class="btn btn-primary">Add Deposit</a>
                </div>
                <div class="card-block table-border-style">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Member</th>
                                    <th>Amount</th>
                                    <th>Date</th>
                                    <th>Fine</th>
                                    <th>Transaction No</th>
                                    <th>Transfer Method</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $deposits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deposit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($deposit->member->name); ?></td>
                                        <td><?php echo e($deposit->amount); ?></td>
                                        <td><?php echo e($deposit->date); ?></td>
                                        <td><?php echo e($deposit->fine ?? 'N/A'); ?></td>
                                        <td><?php echo e($deposit->transaction_no); ?></td>
                                        <td><?php echo e($deposit->transfer_method); ?></td>
                                        <td>
                                           <a href="<?php echo e(route('deposits.show', $deposit->member->id)); ?>" class="btn btn-info btn-sm">View Deposits</a>
                                            <a href="<?php echo e(route('deposits.edit', $deposit->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                                            <form action="<?php echo e(route('deposits.destroy', $deposit->id)); ?>" method="POST" style="display:inline;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Brac Project\example-app\resources\views/deposit/index.blade.php ENDPATH**/ ?>