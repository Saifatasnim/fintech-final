
<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>View Applications</h2>
    <table class="table">
        <thead>
            <tr>
                <th>Email</th>
                <th>Subject</th>
                <th>Body</th>
                <th>Submitted At</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($application->email); ?></td>
                <td><?php echo e($application->subject); ?></td>
                <td><?php echo e($application->body); ?></td>
                <td><?php echo e($application->created_at->format('Y-m-d H:i:s')); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Brac Project\fintracker\fintracker_B\resources\views/member_applications/index.blade.php ENDPATH**/ ?>