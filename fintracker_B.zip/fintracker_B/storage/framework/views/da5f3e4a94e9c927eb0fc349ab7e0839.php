

<?php $__env->startSection('content'); ?>

<div class="page-body">
    <div class="row">
        <div class="col-sm-12">
            <div class="card">
                <div class="card-header">
                    <h5>Edit Investment</h5>
                </div>
                <div class="card-block">
                    <h4 class="sub-title">Edit Investment Details</h4>
                    <form action="<?php echo e(route('investments.update', $investment->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label">Name</label>
                            <div class="col-sm-10">
                                <input type="text" name="name" class="form-control" value="<?php echo e(old('name', $investment->name)); ?>" placeholder="Enter Name" required>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label">Amount</label>
                            <div class="col-sm-10">
                                <input type="number" name="amount" class="form-control" value="<?php echo e(old('amount', $investment->amount)); ?>" placeholder="Enter Amount" required>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label">Category</label>
                            <div class="col-sm-10">
                                <input type="text" name="category" class="form-control" value="<?php echo e(old('category', $investment->category)); ?>" placeholder="Enter Category" required>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label">Investment Date</label>
                            <div class="col-sm-10">
                                <input type="date" name="investment_date" class="form-control" value="<?php echo e(old('investment_date', $investment->investment_date)); ?>" required>
                            </div>
                        </div>

                        <button type="submit" class="btn btn-primary">Update Investment</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Brac Project\fintracker\fintracker_B\resources\views/investments/edit.blade.php ENDPATH**/ ?>