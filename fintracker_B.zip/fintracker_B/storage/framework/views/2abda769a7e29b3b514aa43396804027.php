


        
<?php $__env->startSection('content'); ?>

    <div class="container" id="payment-slip">

        <h3  class="text-center mt-3">Payment Slip</h3>
        
        <!-- Member Details -->
        <div style="display:flex; justify-content: space-around;">
            <div>
            <p><strong>Name:</strong> <?php echo e($member->name); ?></p>
            <p><strong>Phone:</strong> <?php echo e($member->phone); ?></p>
            </div>
            <div>
            <p><strong>Email:</strong> <?php echo e($member->email); ?></p>
            <p><strong>Member ID:</strong> <?php echo e($member->member_id); ?></p>
            </div>
        </div>

        <!-- Deposits Table -->
        <h5>Deposit Details</h5>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Amount</th>
                    <th>Date</th>
                    <th>Fine</th>
                    <th>Transaction No</th>
                    <th>Transfer Method</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $deposits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deposit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($deposit->amount); ?></td>
                        <td><?php echo e($deposit->date); ?></td>
                        <td><?php echo e($deposit->fine); ?></td>
                        <td><?php echo e($deposit->transaction_no); ?></td>
                        <td><?php echo e($deposit->transfer_method); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6">No deposits found for this member.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
         <div style="display:flex;justify-content: space-between">
        <button style="font-size:11px" onclick="downloadPDF()" class="btn btn-success no-print ">Download Slip</button>
        <form action="<?php echo e(route('send.deposit-slip', ['memberId' => $deposit->member->id, 'depositId' => $deposit->id])); ?>" method="POST">
                                             <?php echo csrf_field(); ?>
                                              <button type="submit" class="btn btn-primary btn-sm">Send Slip</button>
                                                </form>

                                                </div>
        <!-- Footer -->
        <!-- <div class="row mt-8">
            <div class="col-6 text-center"><strong>Deposit By</strong></div>
            <div class="col-6 text-center"><strong>Receive By</strong></div>
        </div> -->
    </div>

    <script>
        function downloadPDF() {
            const element = document.getElementById('payment-slip');
            const options = {
                margin: 1,
                filename: 'deposit-slip.pdf',
                image: { type: 'jpeg', quality: 0.98 },
                html2canvas: { scale: 2 },
                jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
            };
            // Generate PDF
            html2pdf().from(element).set(options).save();
        }
    </script>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Brac Project\fintracker\fintracker_B\resources\views/deposit/slip.blade.php ENDPATH**/ ?>