

<?php $__env->startSection('content'); ?>

<div class="page-body">
    <div class="row">
        <div class="col-sm-12">
            <div class="card">
                <div class="card-header">
                    <h5>Edit Deposit</h5>
                </div>
                <div class="card-block">
                    <h4 class="sub-title">Edit Deposit Details</h4>
                    <form action="<?php echo e(route('deposits.update', $deposit->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label">Member</label>
                            <div class="col-sm-10">
                                <select name="member_id" class="form-control" required>
                                    <option value="">Select Member</option>
                                    <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($member->id); ?>" 
                                            <?php echo e($member->id == old('member_id', $deposit->member_id) ? 'selected' : ''); ?>>
                                            <?php echo e($member->name); ?> (<?php echo e($member->member_id); ?>)
                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label">Amount</label>
                            <div class="col-sm-10">
                                <input type="number" name="amount" class="form-control" value="<?php echo e(old('amount', $deposit->amount)); ?>" placeholder="Enter Amount" required>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label">Date</label>
                            <div class="col-sm-10">
                                <input type="date" name="date" class="form-control" value="<?php echo e(old('date', $deposit->date)); ?>" required>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label">Fine</label>
                            <div class="col-sm-10">
                                <input type="number" name="fine" class="form-control" value="<?php echo e(old('fine', $deposit->fine)); ?>" placeholder="Enter Fine (Optional)">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label">Transaction/Account No</label>
                            <div class="col-sm-10">
                                <input type="text" name="transaction_no" class="form-control" value="<?php echo e(old('transaction_no', $deposit->transaction_no)); ?>" placeholder="Enter Transaction No" required>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label">Transfer Method</label>
                            <div class="col-sm-10">
                                <input type="text" name="transfer_method" class="form-control" value="<?php echo e(old('transfer_method', $deposit->transfer_method)); ?>" placeholder="Enter Transfer Method" required>
                            </div>
                        </div>

                        <button type="submit" class="btn btn-primary">Update Deposit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Brac Project\fintracker\fintracker_B\resources\views/deposit/edit.blade.php ENDPATH**/ ?>