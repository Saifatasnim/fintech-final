

<?php $__env->startSection('content'); ?>
<div class="page-body">
    <div class="card">
        <div class="card-header">
            <h5>Expense List</h5><br>
            <a href="<?php echo e(route('expenses.create')); ?>" class="btn btn-primary">
                Add Expense
            </a>
        </div>
        <div class="card-block table-border-style">
            <div class="table-responsive">
                <table class="table">
                <thead>
    <tr>
        <th>#</th>
        <th>Amount</th>
        <th>Date</th>
        <th>Category</th>
        <th>Description</th>
        <th>Actions</th>
    </tr>
</thead>
<tbody>
    <?php $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($loop->iteration); ?></td>
            <td><?php echo e($expense->amount); ?></td>
            <td><?php echo e($expense->date); ?></td>
            <td><?php echo e($expense->category); ?></td>
            <td><?php echo e($expense->description ?? 'N/A'); ?></td>
            <td>
                <a href="<?php echo e(route('expenses.edit', $expense->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                <form action="<?php echo e(route('expenses.destroy', $expense->id)); ?>" method="POST" style="display:inline;">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                </form>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>

                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Brac Project\fintracker\fintracker_B\resources\views/expenses/index.blade.php ENDPATH**/ ?>