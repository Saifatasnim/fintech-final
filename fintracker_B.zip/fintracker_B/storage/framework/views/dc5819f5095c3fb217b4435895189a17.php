

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Investment Details</h1>
        <div>
            <p><strong>Name:</strong> <?php echo e($investment->name); ?></p>
            <p><strong>Amount:</strong> <?php echo e($investment->amount); ?></p>
            <p><strong>Category:</strong> <?php echo e($investment->category); ?></p>
            <p><strong>Investment Date:</strong> <?php echo e($investment->investment_date); ?></p>
        </div>
        <a href="<?php echo e(route('investments.index')); ?>" class="btn btn-primary">Back</a>
        <a href="<?php echo e(route('investments.edit', $investment->id)); ?>" class="btn btn-warning">Edit</a>
        <div class="form-group row">
        
            <div class="col-sm-10">
            <form action="<?php echo e(route('investments.update-returns', $investment->id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <h2 style="margin-top:30px"  for="return_amount">Add New Returns:</h2>
    <input style="width:50%" type="number" class="form-control" name="return_amount" id="return_amount" required>
    <button style="margin-top:20px"  class="btn btn-danger btn-sm" type="submit">Update Returns</button>
</form>
  </div>
     </div>
    </div>






    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Brac Project\fintracker\fintracker_B\resources\views/investments/show.blade.php ENDPATH**/ ?>