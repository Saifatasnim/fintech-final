

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Member Details</h1>
        <div>
            <p><strong>Name:</strong> <?php echo e($member->name); ?></p>
            <p><strong>Phone:</strong> <?php echo e($member->phone); ?></p>
            <p><strong>Email:</strong> <?php echo e($member->email); ?></p>
            <p><strong>NID:</strong> <?php echo e($member->nid); ?></p>
            <p><strong>Address:</strong> <?php echo e($member->address); ?></p>
            <p><strong>Nominee Name:</strong> <?php echo e($member->nominee_name); ?></p>
            <p><strong>Nominee Relation:</strong> <?php echo e($member->nominee_relation); ?></p>
            <p><strong>Member ID:</strong> <?php echo e($member->member_id); ?></p>

        </div>

        <h2>Deposits</h2>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Amount</th>
                    <th>Date</th>
                    <th>Fine</th>
                    <th>Transaction No</th>
                    <th>Transfer Method</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $deposits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deposit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($deposit->amount); ?></td>
                        <td><?php echo e($deposit->date); ?></td>
                        <td><?php echo e($deposit->fine); ?></td>
                        <td><?php echo e($deposit->transaction_no); ?></td>
                        <td><?php echo e($deposit->transfer_method); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="text-center">No deposits found for this member.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

        <a href="<?php echo e(route('members.index')); ?>" class="btn btn-primary">Back to Members</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Brac Project\fintracker\fintracker_B\resources\views/deposit/show.blade.php ENDPATH**/ ?>