

<?php $__env->startSection('content'); ?>

<div class="page-body">
    <div class="row">
        <div class="col-sm-12">
            <div class="card">
                <div class="card-header">
                    <h5>Investment Profit/Loss Status</h5>
                </div>
                <div class="card-block table-border-style">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Investment Name</th>
                                    <th>Amount</th>
                                    <th>Return Amount</th>
                                    <th>ROI(%)</th>
                                    <th>Target ROI(%)</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $investments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $investment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($investment->name); ?></td>
                                        <td>$<?php echo e(number_format($investment->amount, 2)); ?></td>
                                        <td>$<?php echo e(number_format($investment->returns, 2)); ?></td>
                                        <td><?php echo e(number_format($investment->roi, 2)); ?>%</td>
                                        <td><?php echo e(number_format($investment->target, 2)); ?>%</td>
                                        <td>
                                            <?php if($investment->roi > $investment->target): ?>
                                                <span class="text-success">Profit</span>
                                            <?php elseif($investment->target > $investment->roi): ?>
                                                <span class="text-danger">Loss</span>
                                            <?php else: ?>
                                                N/A
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <h5>Profit/Loss Graph</h5>
        </div>
        <div class="card-block">
            <canvas id="profitLossChart" style="height:400px;"></canvas>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const ctx = document.getElementById('profitLossChart').getContext('2d');
            const data = <?php echo json_encode($investmentChartData, 15, 512) ?>;
            const chart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: data.labels,
                    datasets: [{
                        label: 'Profit/Loss',
                        data: data.values,
                        backgroundColor: data.colors
                    }]
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        });
    </script>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Brac Project\fintracker\fintracker_B\resources\views/investments/investment_status.blade.php ENDPATH**/ ?>